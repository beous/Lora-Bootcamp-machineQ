/**
  ******************************************************************************
  * @file    sensor_drivers.h
  * @author  Alec Bath
  * @version V1.0.0
  * @date    13-April-2018
  * @brief   This file contains definitions for the sensor_drivers.c
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2016 STMicroelectronics</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __SENSOR_DRIVERS_H
#define __SENSOR_DRIVERS_H



/* Includes ------------------------------------------------------------------*/


#include "stm32l0xx_hal.h"

/*  ******************    LSM6DSL ACCEL / GYRO Sensor defines     *******************    */
#define LSM6DSL_ADDR          0xD6  // SAD[0] = 1

#define LSM6DSL_ACC_GYRO_WHO_AM_I         0x6A

/************** Device Register  *******************/

#define LSM6DSL_ACC_GYRO_FUNC_CFG_ACCESS    0X01

#define LSM6DSL_ACC_GYRO_SENSOR_SYNC_TIME   0X04
#define LSM6DSL_ACC_GYRO_SENSOR_RES_RATIO   0X05

#define LSM6DSL_ACC_GYRO_FIFO_CTRL1   0X06
#define LSM6DSL_ACC_GYRO_FIFO_CTRL2   0X07
#define LSM6DSL_ACC_GYRO_FIFO_CTRL3   0X08
#define LSM6DSL_ACC_GYRO_FIFO_CTRL4   0X09
#define LSM6DSL_ACC_GYRO_FIFO_CTRL5   0X0A

#define LSM6DSL_ACC_GYRO_DRDY_PULSE_CFG_G   0X0B
#define LSM6DSL_ACC_GYRO_INT1_CTRL    0X0D
#define LSM6DSL_ACC_GYRO_INT2_CTRL    0X0E
#define LSM6DSL_ACC_GYRO_WHO_AM_I_REG   0X0F
#define LSM6DSL_ACC_GYRO_CTRL1_XL   0X10
#define LSM6DSL_ACC_GYRO_CTRL2_G    0X11
#define LSM6DSL_ACC_GYRO_CTRL3_C    0X12
#define LSM6DSL_ACC_GYRO_CTRL4_C    0X13
#define LSM6DSL_ACC_GYRO_CTRL5_C    0X14
#define LSM6DSL_ACC_GYRO_CTRL6_G    0X15
#define LSM6DSL_ACC_GYRO_CTRL7_G    0X16
#define LSM6DSL_ACC_GYRO_CTRL8_XL   0X17
#define LSM6DSL_ACC_GYRO_CTRL9_XL   0X18
#define LSM6DSL_ACC_GYRO_CTRL10_C   0X19

#define LSM6DSL_ACC_GYRO_MASTER_CONFIG    0X1A
#define LSM6DSL_ACC_GYRO_WAKE_UP_SRC    0X1B
#define LSM6DSL_ACC_GYRO_TAP_SRC    0X1C
#define LSM6DSL_ACC_GYRO_D6D_SRC    0X1D
#define LSM6DSL_ACC_GYRO_STATUS_REG   0X1E

#define LSM6DSL_ACC_GYRO_OUT_TEMP_L   0X20
#define LSM6DSL_ACC_GYRO_OUT_TEMP_H   0X21
#define LSM6DSL_ACC_GYRO_OUTX_L_G   0X22
#define LSM6DSL_ACC_GYRO_OUTX_H_G   0X23
#define LSM6DSL_ACC_GYRO_OUTY_L_G   0X24
#define LSM6DSL_ACC_GYRO_OUTY_H_G   0X25
#define LSM6DSL_ACC_GYRO_OUTZ_L_G   0X26
#define LSM6DSL_ACC_GYRO_OUTZ_H_G   0X27
#define LSM6DSL_ACC_GYRO_OUTX_L_XL    0X28
#define LSM6DSL_ACC_GYRO_OUTX_H_XL    0X29
#define LSM6DSL_ACC_GYRO_OUTY_L_XL    0X2A
#define LSM6DSL_ACC_GYRO_OUTY_H_XL    0X2B
#define LSM6DSL_ACC_GYRO_OUTZ_L_XL    0X2C
#define LSM6DSL_ACC_GYRO_OUTZ_H_XL    0X2D

/*  *****************    LSM303AGR ACCEL / MAG Sensor defines     *******************    */
#define LSM303AGR_MAG_ADDR         0x3C

#define LSM303AGR_MAG_WHO_AM_I         0x40
#define LSM303AGR_MAG_OFFSET_X_REG_L    0X45
#define LSM303AGR_MAG_OFFSET_X_REG_H    0X46
#define LSM303AGR_MAG_OFFSET_Y_REG_L    0X47
#define LSM303AGR_MAG_OFFSET_Y_REG_H    0X48
#define LSM303AGR_MAG_OFFSET_Z_REG_L    0X49
#define LSM303AGR_MAG_OFFSET_Z_REG_H    0X4A
#define LSM303AGR_MAG_WHO_AM_I_REG    0X4F
#define LSM303AGR_MAG_CFG_REG_A   0X60
#define LSM303AGR_MAG_CFG_REG_B   0X61
#define LSM303AGR_MAG_CFG_REG_C   0X62
#define LSM303AGR_MAG_INT_CTRL_REG    0X63
#define LSM303AGR_MAG_INT_SOURCE_REG    0X64
#define LSM303AGR_MAG_INT_THS_L_REG   0X65
#define LSM303AGR_MAG_INT_THS_H_REG   0X66
#define LSM303AGR_MAG_STATUS_REG    0X67
#define LSM303AGR_MAG_OUTX_L_REG    0X68
#define LSM303AGR_MAG_OUTX_H_REG    0X69
#define LSM303AGR_MAG_OUTY_L_REG    0X6A
#define LSM303AGR_MAG_OUTY_H_REG    0X6B
#define LSM303AGR_MAG_OUTZ_L_REG    0X6C
#define LSM303AGR_MAG_OUTZ_H_REG    0X6D

/*  ******************    LPS22HB Pressure Sensor defines     *******************    */

#define LPS22HB_ADDR                        0xBA  /**< LPS22HB I2C Address High */
#define LPS22HB_RES_CONF_REG     (uint8_t)0x1A

typedef enum
{

  LPS22HB_ODR_ONE_SHOT  = (uint8_t)0x00,         /*!< Output Data Rate: one shot */
  LPS22HB_ODR_1HZ       = (uint8_t)0x10,         /*!< Output Data Rate: 1Hz */
  LPS22HB_ODR_10HZ       = (uint8_t)0x20,         /*!< Output Data Rate: 10Hz */
  LPS22HB_ODR_25HZ    = (uint8_t)0x30,         /*!< Output Data Rate: 25Hz */
  LPS22HB_ODR_50HZ      = (uint8_t)0x40,          /*!< Output Data Rate: 50Hz */
  LPS22HB_ODR_75HZ      = (uint8_t)0x50          /*!< Output Data Rate: 75Hz */
} eLPS22HB_ODR;

#define LPS22HB_CTRL_REG1               0x10

#define LPS22HB_ODR_MASK                0x70
#define LPS22HB_LPFP_MASK               0x08
#define LPS22HB_LPFP_CUTOFF_MASK        0x04
#define LPS22HB_BDU_MASK                0x02
#define LPS22HB_SIM_MASK                0x01


#define LPS22HB_CTRL_REG2               0x11
#define LPS22HB_ADD_INC_BIT             0x10

#define LPS22HB_STATUS_REG              0x27
#define LPS22HB_TOR_BIT                 0x20
#define LPS22HB_POR_BIT                 0x10
#define LPS22HB_TDA_BIT                 0x02
#define LPS22HB_PDA_BIT                 0x01



#define LPS22HB_PRESS_OUT_XL_REG        (uint8_t)0x28
#define LPS22HB_PRESS_OUT_L_REG        (uint8_t)0x29
#define LPS22HB_PRESS_OUT_H_REG        (uint8_t)0x2A  // Pout(hPA)=(PRESS_OUT_H & PRESS_OUT_L & PRESS_OUT_XL)[dec]/4096.

#define LPS22HB_TEMP_OUT_L_REG         (uint8_t)0x2B  // Tout(degC)=TEMP_OUT/100
#define LPS22HBH_TEMP_OUT_H_REG         (uint8_t)0x2C

/*  ******************    HTS221 Humidity Sensor defines     *******************    */

#define HTS221_ADDR                         0xBE  /**< HTS221 I2C Address */
#define HTS221_OK   0
#define HTS221_ERROR 1


#define HTS221_CTRL_REG1      (uint8_t)0x20
#define HTS221_PD_BIT          HTS221_BIT(7)
#define HTS221_BDU_BIT         HTS221_BIT(2)
#define HTS221_ODR_BIT         HTS221_BIT(0)
#define HTS221_PD_MASK        (uint8_t)0x80
#define HTS221_BDU_MASK       (uint8_t)0x04
#define HTS221_ODR_MASK       (uint8_t)0x03
#define HTS221_ODR_ONE_SHOT    0x00     
#define HTS221_ODR_1HZ         0x01     
#define HTS221_ODR_7HZ         0x02
#define HTS221_ODR_12_5HZ      0x03

#define HTS221_CTRL_REG2      (uint8_t)0x21
#define HTS221_BOOT_BIT        HTS221_BIT(7)
#define HTS221_HEATHER_BIT     HTS221_BIT(1)
#define HTS221_ONESHOT_BIT     HTS221_BIT(0)
#define HTS221_BOOT_MASK      (uint8_t)0x80
#define HTS221_HEATHER_MASK   (uint8_t)0x02
#define HTS221_ONE_SHOT_MASK  (uint8_t)0x01

#define HTS221_CTRL_REG3      (uint8_t)0x22
#define HTS221_DRDY_H_L_BIT    HTS221_BIT(7)
#define HTS221_PP_OD_BIT       HTS221_BIT(6)
#define HTS221_DRDY_BIT        HTS221_BIT(2)

#define HTS221_DRDY_H_L_MASK  (uint8_t)0x80
#define HTS221_PP_OD_MASK     (uint8_t)0x40
#define HTS221_DRDY_MASK      (uint8_t)0x04

#define HTS221_STATUS_REG    (uint8_t)0x27
#define HTS221_H_DA_BIT       HTS221_BIT(1)
#define HTS221_T_DA_BIT       HTS221_BIT(0)
#define HTS221_HDA_MASK      (uint8_t)0x02
#define HTS221_TDA_MASK      (uint8_t)0x01


#define HTS221_HR_OUT_L_REG        (uint8_t)0x28
#define HTS221_HR_OUT_H_REG        (uint8_t)0x29
#define HTS221_TEMP_OUT_L_REG         (uint8_t)0x2A
#define HTS221_TEMP_OUT_H_REG         (uint8_t)0x2B
#define HTS221_H0_RH_X2        (uint8_t)0x30
#define HTS221_H1_RH_X2        (uint8_t)0x31
#define HTS221_T0_DEGC_X8      (uint8_t)0x32
#define HTS221_T1_DEGC_X8      (uint8_t)0x33
#define HTS221_T0_T1_DEGC_H2   (uint8_t)0x35
#define HTS221_H0_T0_OUT_L     (uint8_t)0x36
#define HTS221_H0_T0_OUT_H     (uint8_t)0x37
#define HTS221_H1_T0_OUT_L     (uint8_t)0x3A
#define HTS221_H1_T0_OUT_H     (uint8_t)0x3B
#define HTS221_T0_OUT_L        (uint8_t)0x3C
#define HTS221_T0_OUT_H        (uint8_t)0x3D
#define HTS221_T1_OUT_L        (uint8_t)0x3E
#define HTS221_T1_OUT_H        (uint8_t)0x3F



typedef struct
{
  float pressure;    /* in mbar */  
  float temperature; /* in �C   */
  float humidity;    /* in %    */
  int16_t altitudeBar ;       /* in m * 10 */
  int32_t accel_x;      // acceleration on x-axis
  int32_t accel_y;      // acceleration on y-axis
  int32_t accel_z;      // acceleration on z-axis
  int32_t gyro_x;       // angular acceleration on x-axis
  int32_t gyro_y;       // angular acceleration on y-axis
  int32_t gyro_z;       // angular acceleration on z-axis
  int32_t magneto_x;    // magnetic position on x-axis
  int32_t magneto_y;    // magnetic position on y-axis
  int32_t magneto_z;    // magnetic position on z-axis
  // ***  add additional sensor types here  ***
} mysensor_t;

typedef struct {
  unsigned pressureFlag: 1;
  unsigned temperatureFlag: 1;
  unsigned humidityFlag: 1;
  unsigned accelFlag: 1;
  unsigned gyroFlag: 1;
  unsigned magnetoFlag: 1;
  unsigned EnviromentFlag: 1;
} mysensorflags_t;
               

/* Exported functions ------------------------------------------------------- */
void Sensor_I2C_Init(void);
HAL_StatusTypeDef MyHumidityRead(mysensor_t *mysensor_data);
HAL_StatusTypeDef MyHumidityInit(mysensor_t *mysensor_data);
HAL_StatusTypeDef MyHumidityDisable(void);
HAL_StatusTypeDef MyHTS221_TempRead(mysensor_t *mysensor_data);

HAL_StatusTypeDef MyPressureInit(mysensor_t *mysensor_data);
HAL_StatusTypeDef MyPressureDisable(void);
HAL_StatusTypeDef MyPressureRead(mysensor_t *mysensor_data);

HAL_StatusTypeDef MyAccelGyroInit(mysensor_t *mysensor_data);
HAL_StatusTypeDef MyAccelGyroDisable(void);
HAL_StatusTypeDef MyAccelGyroRead(mysensor_t *mysensor_data);

HAL_StatusTypeDef MyMagInit(mysensor_t *mysensor_data);
HAL_StatusTypeDef MyMagDisable(void);
HAL_StatusTypeDef MyMagRead(mysensor_t *mysensor_data);



#endif /* __SENSOR_DRIVERS_H*/

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
