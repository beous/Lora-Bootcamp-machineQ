/******************************************************************************
  * @file    ipso_objects.h
  * @author  Alec Bath - STMicroelectronics
  * @version V1
  * @date    21-March-2017
  * @brief   Definitions for IPSO Smart Objects Data Types - https://www.ipso-alliance.org/
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2017 STMicroelectronics International N.V. 
  * All rights reserved.</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without 
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice, 
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other 
  *    contributors to this software may be used to endorse or promote products 
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this 
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under 
  *    this license is void and will automatically terminate your rights under 
  *    this license. 
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" 
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT 
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT 
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __IPSO_OBJECTS_H__
#define __IPSO_OBJECTS_H__


/* Includes ------------------------------------------------------------------*/


/* Private typedef -----------------------------------------------------------*/
typedef enum eLPPSensorDataType_t
{
      DigitalInput = 0,
      DigitalOutput = 1,
      AnalogInput = 2,
      AnalogOutput = 3,
      IlluminanceSensor = 0x65,
      PresenceSensor = 0x66,
      TemperatureSensor = 0x67,
      HumiditySensor = 0x68,
      Accelerometer = 0x71,
      Magnetometer = 0x72,
      Barometer = 0x73,
      Gyrometer = 0x86,
      GPS_Location = 0x88,
      EnviroSensors
} LPPSensorDataType_t;


typedef struct sLPPSensors_t
{
    uint8_t digital_input;        // 0 or 1
    uint8_t digital_output;       // 0 or 1
    uint8_t analog_input[2];      // 0.01 signed
    uint8_t analog_output[2];     // 0.01 signed
    uint8_t illuminance_sensor[2];         // 1 Lux unsigned
    uint8_t presence_sensor;        // 0 or 1
    uint8_t temperature_sensor[2];     // 0.1 degC signed
    uint8_t humidity_sensor;  // 0.5% unsigned
    uint8_t accelerometer[6];  // 0.001G signed / axis
    uint8_t barometer[2];  // 0.1hPa unsigned
    uint8_t gyrometer[6];  // 0.01deg/s signed / axis
    uint8_t magnetometer[6];  // 0.01deg/s signed / axis
    uint8_t gps_location[9];  // Long / Lat 0.0001deg, Altitude 0.01meter
} LPPSensors_t;


/* Private define ------------------------------------------------------------*/
#define LPP_DIGITAL_INPUT                             0
#define LPP_DIGITAL_OUTPUT                            1
#define LPP_ANALOG_INPUT                              2
#define LPP_ANALOG_OUTPUT                             3
#define LPP_ILLUMINANCE_SENSOR                        0x65
#define LPP_PRESENCE_SENSOR                           0x66
#define LPP_TEMPERATURE_SENSOR                        0x67
#define LPP_HUMIDITY_SENSOR                           0x68
#define LPP_ACCELEROMETER                             0x71
#define LPP_MAGNETOMETER                              0x72 // not used by Cayenne yet...
#define LPP_BAROMETER                                 0x73
#define LPP_GYROMETER                                 0x86
#define LPP_GPS_LOCATION                              0x88

#define LPP_BAROMETER_CHANNEL_NUM                   0x00
#define LPP_TEMP_CHANNEL_NUM                        0x01
#define LPP_HUMIDITY_CHANNEL_NUM                    0x02
#define LPP_ACCELEROMETER_CHANNEL_NUM               0x03
#define LPP_GYROMETER_CHANNEL_NUM                   0x04
#define LPP_MAGNETOMETER_CHANNEL_NUM                0x05

#define LPP_DIGI_INPUT_CHANNEL_NUM                  0x08
#define LPP_LUX_SENSOR_CHANNEL_NUM                  0x09
#define LPP_ANA_INPUT_CHANNEL_NUM                   0x0A
#define LPP_DIGI_OUTPUT_CHANNEL_NUM                 0x0B
#define LPP_ANA_OUTPUT_CHANNEL_NUM                  0x0C
#define LPP_PRESENCE_CHANNEL_NUM                    0x0D
#define LPP_GPS_LOC_CHANNEL_NUM                     0x0F

#define LPP_DIGI_INPUT_BUFSIZE                      3
#define LPP_DIGI_OUTPUT_BUFSIZE                     3
#define LPP_ANALOG_INPUT_BUFSIZE                    4
#define LPP_ANALOG_OUTPUT_BUFSIZE                   4
#define LPP_LUX_SENSOR_BUFSIZE                      4
#define LPP_PRESENCE_BUFSIZE                        3
#define LPP_BARO_SENSOR_BUFSIZE                     4
#define LPP_TEMP_SENSOR_BUFSIZE                     4
#define LPP_HUMIDITY_SENSOR_BUFSIZE                 3
#define LPP_ACCEL_SENSOR_BUFSIZE                    8
#define LPP_GYRO_SENSOR_BUFSIZE                     8
#define LPP_MAGNETO_SENSOR_BUFSIZE                  8
#define LPP_GPS_LOC_BUFSIZE                         11
#define LPP_ENVIRO_SENSORS_BUFSIZE                  11


/* Private macro -------------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


#endif /* __IPSO_OBJECTS_H__ */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
