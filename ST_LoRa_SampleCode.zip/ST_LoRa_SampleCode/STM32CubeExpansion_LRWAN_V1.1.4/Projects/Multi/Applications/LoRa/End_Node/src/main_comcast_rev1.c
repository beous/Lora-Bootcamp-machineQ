/******************************************************************************
  * @file    main.c
  * @author  MCD Application Team / Alec Bath
  * @version V1.1.4
  * @date    30-April-2018
  * @brief   modifications for Comcast End Node commissioning
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2017 STMicroelectronics International N.V. 
  * All rights reserved.</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without 
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice, 
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other 
  *    contributors to this software may be used to endorse or promote products 
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this 
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under 
  *    this license is void and will automatically terminate your rights under 
  *    this license. 
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" 
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT 
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT 
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */


/* Includes ------------------------------------------------------------------*/
#include "hw.h"
#include "low_power_manager.h"
#include "lora.h"
#include "timeServer.h"
#include "vcom.h"
#include "version.h"
#include "terminalHandler.h"
#include "bsp_all_sensors_IKS01A2.h"
#include "ipso_objects.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define APP_TX_DUTYCYCLE                            5000  // application data transmission duty cycle. 5s, value in [ms].
#define LORAWAN_ADR_STATE                           LORAWAN_ADR_ON    //  * LoRaWAN Adaptive Data Rate
#define LORAWAN_DEFAULT_DATA_RATE                   DR_0
#define LORAWAN_APP_PORT                            2
#define JOINREQ_NBTRIALS                            3     //  Number of trials for the join request.
#define LORAWAN_DEFAULT_CLASS                       CLASS_A
#define LORAWAN_DEFAULT_CONFIRM_MSG_STATE           LORAWAN_UNCONFIRMED_MSG
#define LORAWAN_APP_DATA_BUFF_SIZE                  64


/* Private macro -------------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
static void LORA_RxData( lora_AppData_t *AppData);  /* call back when LoRa endNode has received a frame*/
static void LORA_HasJoined( void );  /* call back when LoRa endNode has just joined*/
static void LORA_ConfirmClass ( DeviceClass_t Class );  /* call back when LoRa endNode has just switch the class*/
static void Send( void );  /* LoRa endNode send request*/
static void LoraStartTx(TxEventType_t EventType);  /* start the tx process*/
static void OnTxTimerEvent( void );  /* tx timer callback function*/

/* Private variables ---------------------------------------------------------*/
HAL_StatusTypeDef HAL_Status;
volatile uint32_t i = 0;
RxBufData_t RxBufferData;

static uint8_t AppDataBuff[LORAWAN_APP_DATA_BUFF_SIZE];
static lora_AppData_t AppData={ AppDataBuff,  0 ,0 };

static LoRaMainCallback_t LoRaMainCallbacks ={ HW_GetBatteryLevel, HW_GetTemperatureLevel, HW_GetUniqueId, HW_GetRandomSeed, LORA_RxData, LORA_HasJoined, LORA_ConfirmClass};
static TimerEvent_t TxTimer;
static TimerEvent_t TxLedTimer; //  Timer to handle the application Tx Led to toggle
static void OnTimerLedEvent( void );
static  LoRaParam_t LoRaParamInit= {LORAWAN_ADR_STATE, LORAWAN_DEFAULT_DATA_RATE, LORAWAN_PUBLIC_NETWORK, JOINREQ_NBTRIALS};  // Initialises the Lora Parameters

LPPSensorDataType_t SensorDataPacket;
LPPSensors_t LPPSensors;
volatile uint32_t i;
sensorflags_t sensorflags;

/* Private functions ---------------------------------------------------------*/
  
int main( void )
{
  HAL_Init( );    /* STM32 HAL library initialization*/
  SystemClock_Config( );    /* Configure the system clock*/
  DBG_Init( );    /* Configure the debug mode*/
  HW_Init( );    /* Configure the hardware*/
  LPM_SetOffMode(LPM_APPLI_Id , LPM_Disable );    /*Disable Stand-by mode*/
  SensorDataPacket = Accelerometer;  // set initial sensor type to send over LoRa

  LORA_Init( &LoRaMainCallbacks, &LoRaParamInit);    /* Configure the Lora Stack*/
              
  BSP_LED_Init( LED1 );
  
  Terminal_UART_Init();

  
  BSP_LED_Init( LED2 );
  BSP_LED_Init( LED3 );
  BSP_LED_Init( LED4 );
  

  printf("\f\r\n\n\n\n\n\n\n\n\n\n****************************");
  printf("\r\nWelcome to Comcast machineQ!");
  printf("\r\n****************************");

  HAL_Status = GetCommission(&RxBufferData);  // check and retrieve eeprom commisssioning info
  
  if (HAL_Status != HAL_OK)  // we need to setup commissioning parameters
  {
      HAL_Status = SetCommission(&RxBufferData);
  }

  else
  {
    printf("\r\n\n Commissioning Parameters:");
    printf    ("\r\n =========================");
    printf("\r\n\n DEVEUI = %x%x%x%x", RxBufferData.deveui_val[0], RxBufferData.deveui_val[1], RxBufferData.deveui_val[2], RxBufferData.deveui_val[3]);
    printf("%x%x%x%x", RxBufferData.deveui_val[4], RxBufferData.deveui_val[5], RxBufferData.deveui_val[6], RxBufferData.deveui_val[7]);
    printf("\r\n\n APPEUI = %x%x%x%x", RxBufferData.appeui_val[0], RxBufferData.appeui_val[1], RxBufferData.appeui_val[2], RxBufferData.appeui_val[3]);
    printf("%x%x%x%x", RxBufferData.appeui_val[4], RxBufferData.appeui_val[5], RxBufferData.appeui_val[6], RxBufferData.appeui_val[7]);
    printf("\r\n\n APPKEY = %x%x%x%x", RxBufferData.appkey_val[0], RxBufferData.appkey_val[1], RxBufferData.appkey_val[2], RxBufferData.appkey_val[3]);
    printf("%x%x%x%x", RxBufferData.appkey_val[4], RxBufferData.appkey_val[5], RxBufferData.appkey_val[6], RxBufferData.appkey_val[7]);
    printf("%x%x%x%x", RxBufferData.appkey_val[8], RxBufferData.appkey_val[9], RxBufferData.appkey_val[10], RxBufferData.appkey_val[11]);
    printf("%x%x%x%x", RxBufferData.appkey_val[12], RxBufferData.appkey_val[13], RxBufferData.appkey_val[14], RxBufferData.appkey_val[15]);
    printf("\r\n\n Transmit Duty Cycle = %d\r\n\n", RxBufferData.tx_dutycycle);

    for (i=2000000; i!=0; i--);
    printf("\r\n\n\n Press C within the next 5 seconds to reconfigure commissioning...");

    HAL_Status = CheckForReCommission(&RxBufferData);  // check and retrieve eeprom commisssioning info

    if (HAL_Status == HAL_TIMEOUT)  // timeout - proceed
    {
      printf("\r\n\n\n Starting Network JOIN procedure...");
    }

    else if (HAL_Status == HAL_OK)  // c pressed - recommission
    {
            HAL_Status = SetCommission(&RxBufferData);
    }
  }
  
  CommissionSet(RxBufferData.deveui_val);  // move comm params to LoRa stack

  LORA_Join( );
  LoraStartTx( TX_ON_TIMER) ;

  while( 1 )
  {    
    BSP_LED_Off(LED3);
    for (i=2000000; i!=0; i--);
    BSP_LED_On(LED3);
    for (i=500000; i!=0; i--);

    DISABLE_IRQ( );  // pending interrupts will disable Low power mode
#ifndef LOW_POWER_DISABLE
    LPM_EnterLowPower( );
#endif
    ENABLE_IRQ();

  }  // while(1)
}



static void LORA_HasJoined( void )
{
#if( OVER_THE_AIR_ACTIVATION != 0 )
  printf("\r\n\nJOINED\n\r");
#endif
  LORA_RequestClass( LORAWAN_DEFAULT_CLASS );
}


static void Send( void )
{
  sensor_t sensor_data;

  if ( LORA_JoinStatus () != LORA_SET)
  {
    return;      /*Not joined, try again later*/
  }

  BSP_sensor_Read(&sensor_data);

  switch (SensorDataPacket)
  {    
    case Accelerometer:
      AppData.BuffSize = LPP_ACCEL_SENSOR_BUFSIZE;
      AppData.Buff[0] = LPP_ACCELEROMETER_CHANNEL_NUM;  // channel#
      AppData.Buff[1] = LPP_ACCELEROMETER;  // accelerometer data = 0x71, 6 data bytes
      AppData.Buff[2] = (sensor_data.accel_x >> 8 ) & 0x00FF;   		// 5  : Accel-X MSB
      AppData.Buff[3] = sensor_data.accel_x & 0x00FF;							// 6  : Accel-X LSB
      AppData.Buff[4] = (sensor_data.accel_y >> 8 ) & 0x00FF;   		// 5  : Accel-Y MSB
      AppData.Buff[5] = sensor_data.accel_y & 0x00FF;							// 6  : Accel-Y LSB
      AppData.Buff[6] = (sensor_data.accel_z >> 8 ) & 0x00FF;   		// 5  : Accel-Z MSB
      AppData.Buff[7] = sensor_data.accel_z & 0x00FF;							// 6  : Accel-Z LSB
      SensorDataPacket = Gyrometer;  // set to gyro for next sensor transmission

      printf("\r\n\n Accelerometer:  X=%x%x  Y=%x%x  Z=%x%x", AppData.Buff[2], AppData.Buff[3], AppData.Buff[4], AppData.Buff[5], AppData.Buff[6], AppData.Buff[7]);

    break;  

    case Gyrometer:
      AppData.BuffSize = LPP_GYRO_SENSOR_BUFSIZE;
      AppData.Buff[0] = LPP_GYROMETER_CHANNEL_NUM;  // channel#
      AppData.Buff[1] = LPP_GYROMETER;  // accelerometer data = 0x71, 6 data bytes
      AppData.Buff[2] = (sensor_data.gyro_x >> 8 ) & 0x00FF;   		// Gyro X MSB
      AppData.Buff[3] = sensor_data.gyro_x & 0x00FF;   		        // Gyro X LSB
      AppData.Buff[4] = (sensor_data.gyro_y >> 8 ) & 0x00FF;   		// Gyro Y MSB
      AppData.Buff[5] = sensor_data.gyro_y & 0x00FF;   		        // Gyro Y LSB
      AppData.Buff[6] = (sensor_data.gyro_z >> 8 ) & 0x00FF;   		// Gyro Z MSB
      AppData.Buff[7] = sensor_data.gyro_z & 0x00FF;   		        // Gyro Z LSB
      SensorDataPacket = Magnetometer;  // set to magneto for next sensor transmission

    printf("\r\n\n Gyroscope:  X=%x%x  Y=%x%x  Z=%x%x", AppData.Buff[2], AppData.Buff[3], AppData.Buff[4], AppData.Buff[5], AppData.Buff[6], AppData.Buff[7]);
    break;

    case Magnetometer:
      AppData.BuffSize = LPP_MAGNETO_SENSOR_BUFSIZE;
      AppData.Buff[0] = LPP_MAGNETOMETER_CHANNEL_NUM;  // channel#
      AppData.Buff[1] = LPP_MAGNETOMETER;  // magnetometer data = 0xxx, 6 data bytes
      AppData.Buff[2] = (sensor_data.magneto_x >> 8 ) & 0x00FF;   		// 5  : Accel-X MSB
      AppData.Buff[3] = sensor_data.magneto_x & 0x00FF;							// 6  : Accel-X LSB
      AppData.Buff[4] = (sensor_data.magneto_y >> 8 ) & 0x00FF;   		// 5  : Accel-Y MSB
      AppData.Buff[5] = sensor_data.magneto_y & 0x00FF;							// 6  : Accel-Y LSB
      AppData.Buff[6] = (sensor_data.magneto_z >> 8 ) & 0x00FF;   		// 5  : Accel-Z MSB
      AppData.Buff[7] = sensor_data.magneto_z & 0x00FF;							// 6  : Accel-Z LSB
      SensorDataPacket = EnviroSensors;

      printf("\r\n\n Magnetometer:  X=%x%x  Y=%x%x  Z=%x%x", AppData.Buff[2], AppData.Buff[3], AppData.Buff[4], AppData.Buff[5], AppData.Buff[6], AppData.Buff[7]);
    break;  
    
    case EnviroSensors:
      AppData.BuffSize = LPP_ENVIRO_SENSORS_BUFSIZE;  //  all 11 bytes for humidty/temp/baro
      AppData.Buff[0] = LPP_BAROMETER_CHANNEL_NUM;
      AppData.Buff[1] = LPP_BAROMETER;              // pressure data = 0x73, 2 data bytes
      AppData.Buff[2] = ( sensor_data.pressure >> 8 ) & 0xFF;   // pressure MSB in 0.1 hPa
      AppData.Buff[3] = sensor_data.pressure & 0xFF;            // pressure LSB in 0.1 hPa
      AppData.Buff[4] = LPP_TEMP_CHANNEL_NUM;
      AppData.Buff[5] = LPP_TEMPERATURE_SENSOR;          // temp data = 0x67, 2 data bytes
      AppData.Buff[6] = ( sensor_data.temperature >> 8 ) & 0xFF;    //  MSB temp in 0.1 degC
      AppData.Buff[7] = sensor_data.temperature & 0xFF;             //  LSB temp in 0.1 degC
      AppData.Buff[8] = LPP_HUMIDITY_CHANNEL_NUM;
      AppData.Buff[9] = LPP_HUMIDITY_SENSOR;            // humid data = 0x68, 1 data byte
      AppData.Buff[10] =  sensor_data.humidity & 0xFF;							// humidity in 0.5%
      SensorDataPacket = Accelerometer;  // set next sensor data packet event to send next time

      printf("\r\n\n Barometer:  %d (0.1hPa)", sensor_data.pressure);
      printf("\r\n Temperature:  %d (0.1degC)", sensor_data.temperature);
      printf("\r\n Humidity:  %d (0.5%)", sensor_data.humidity);
    break;
    
    default:
      SensorDataPacket = Accelerometer;  // set next sensor data packet event to send next time
    break;
  }

  AppData.Port = LORAWAN_APP_PORT;
  LORA_send( &AppData, LORAWAN_DEFAULT_CONFIRM_MSG_STATE);
}


static void LORA_RxData( lora_AppData_t *AppData )
{
  DBG_PRINTF("PACKET RECEIVED ON PORT %d\n\r", AppData->Port);

  switch (AppData->Port)
  {
    case 3:
    /*this port switches the class*/
    if( AppData->BuffSize == 1 )
    {
      switch (  AppData->Buff[0] )
      {
        case 0:
        {
          LORA_RequestClass(CLASS_A);
          break;
        }
        case 1:
        {
          LORA_RequestClass(CLASS_B);
          break;
        }
        case 2:
        {
          LORA_RequestClass(CLASS_C);
          break;
        }
        default:
          break;
      }
    }
    break;
    case LORAWAN_APP_PORT:
    if( AppData->BuffSize == 1 )
    {
      if (AppData->Buff[0] == RESET )
      {
        PRINTF("LED OFF\n\r");
        LED_Off( LED_BLUE ) ; 
      }
      else
      {
        PRINTF("LED ON\n\r");
        LED_On( LED_BLUE ) ; 
      }
    }
    break;

  default:
    break;
  }
}

static void OnTxTimerEvent( void )
{
  Send( );
  TimerStart( &TxTimer);     /*Wait for next tx slot*/
}


static void LoraStartTx(TxEventType_t EventType)
{
  if (EventType == TX_ON_TIMER)
  {
    /* send everytime timer elapses */
    TimerInit( &TxTimer, OnTxTimerEvent );
    TimerSetValue( &TxTimer,  APP_TX_DUTYCYCLE); 
    OnTxTimerEvent();
  }
  else
  {
    /* send everytime button is pushed */
    GPIO_InitTypeDef initStruct={0};
  
    initStruct.Mode =GPIO_MODE_IT_RISING;
    initStruct.Pull = GPIO_PULLUP;
    initStruct.Speed = GPIO_SPEED_HIGH;

    HW_GPIO_Init( USER_BUTTON_GPIO_PORT, USER_BUTTON_PIN, &initStruct );
    HW_GPIO_SetIrq( USER_BUTTON_GPIO_PORT, USER_BUTTON_PIN, 0, Send );
  }
}

static void LORA_ConfirmClass ( DeviceClass_t Class )
{
  PRINTF("switch to class %c done\n\r","ABC"[Class] );

  /*Optionnal*/
  /*informs the server that switch has occurred ASAP*/
  AppData.BuffSize = 0;
  AppData.Port = LORAWAN_APP_PORT;
  
  LORA_send( &AppData, LORAWAN_UNCONFIRMED_MSG);
}

static void OnTimerLedEvent( void )
{
  LED_Off( LED_RED1 ) ; 
}

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
