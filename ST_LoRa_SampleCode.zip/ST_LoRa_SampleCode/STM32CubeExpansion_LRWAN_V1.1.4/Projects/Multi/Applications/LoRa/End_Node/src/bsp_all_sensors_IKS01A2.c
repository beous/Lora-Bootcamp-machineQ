 /******************************************************************************
  * @file    bsp.c
  * @author  MCD Application Team
  * @version V1.1.0
  * @date    27-February-2017
  * @brief   manages the sensors on the application
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2017 STMicroelectronics International N.V. 
  * All rights reserved.</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without 
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice, 
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other 
  *    contributors to this software may be used to endorse or promote products 
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this 
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under 
  *    this license is void and will automatically terminate your rights under 
  *    this license. 
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" 
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT 
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT 
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
  
  /* Includes ------------------------------------------------------------------*/
#include <string.h>
#include <stdlib.h>
#include "hw.h"
#include "timeServer.h"
#include "bsp_all_sensors_IKS01A2.h"

#define X_NUCLEO_IKS01A2   // Use IKS-01A2 sensor shield


#if defined(SENSOR_ENABLED)

#include "x_nucleo_iks01a2_humidity.h"
#include "x_nucleo_iks01a2_pressure.h"
#include "x_nucleo_iks01a2_temperature.h"
#include "x_nucleo_iks01a2_accelero.h"  // ARB
#include "x_nucleo_iks01a2_gyro.h"  // ARB
#include "x_nucleo_iks01a2_magneto.h"  // ARB

#endif  /* SENSOR_ENABLED */


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Exported functions ---------------------------------------------------------*/

/* Private variables ---------------------------------------------------------*/
void *HUMIDITY_handle = NULL;
void *TEMPERATURE_handle = NULL;
void *PRESSURE_handle = NULL;
void *LSM6DSL_ACCEL_handle = NULL;
void *LSM6DSL_GYRO_handle = NULL;
void *LSM303AGR_ACCEL_handle = NULL;
void *LSM303AGR_MAG_handle = NULL;

DrvStatusTypeDef DriveStatus;

/* Private function prototypes -----------------------------------------------*/

/* Exported functions ---------------------------------------------------------*/

void  BSP_sensor_Init( void  )
{
  DriveStatus = BSP_HUMIDITY_Init( HTS221_H_0, &HUMIDITY_handle );
  DriveStatus = BSP_TEMPERATURE_Init( HTS221_T_0, &TEMPERATURE_handle );
  DriveStatus = BSP_PRESSURE_Init( PRESSURE_SENSORS_AUTO, &PRESSURE_handle );
  DriveStatus = BSP_ACCELERO_Init(LSM6DSL_X_0, &LSM6DSL_ACCEL_handle);
  //DriveStatus = BSP_ACCELERO_Init(LSM303AGR_X_0, &LSM303AGR_ACCEL_handle);
  DriveStatus = BSP_GYRO_Init(LSM6DSL_G_0, &LSM6DSL_GYRO_handle);
  DriveStatus = BSP_MAGNETO_Init(LSM303AGR_M_0, &LSM303AGR_MAG_handle);
	
  DriveStatus = BSP_HUMIDITY_Sensor_Enable( HUMIDITY_handle );
  DriveStatus = BSP_TEMPERATURE_Sensor_Enable( TEMPERATURE_handle );
  DriveStatus = BSP_PRESSURE_Sensor_Enable( PRESSURE_handle );
  DriveStatus = BSP_ACCELERO_Sensor_Enable(LSM6DSL_ACCEL_handle);
  DriveStatus = BSP_GYRO_Sensor_Enable(LSM6DSL_GYRO_handle);
  //DriveStatus = BSP_ACCELERO_Sensor_Enable(LSM303AGR_ACCEL_handle);
  DriveStatus = BSP_MAGNETO_Sensor_Enable(LSM303AGR_MAG_handle);
  //XNUCLEO6180XA1_GPIO_Init();
}


void BSP_sensor_Read( sensor_t *sensor_data)
{
  float HUMIDITY_Value = 0;
  float TEMPERATURE_Value = 0;
  float PRESSURE_Value = 0;
  SensorAxes_t AccelSensorAxisData;
  SensorAxes_t GyroSensorAxisData;
  SensorAxes_t MagnetoSensorAxisData;

  BSP_PRESSURE_Sensor_Enable( PRESSURE_handle );

  BSP_HUMIDITY_Get_Hum(HUMIDITY_handle, &HUMIDITY_Value);
  BSP_TEMPERATURE_Get_Temp(TEMPERATURE_handle, &TEMPERATURE_Value);
  BSP_PRESSURE_Get_Press(PRESSURE_handle, &PRESSURE_Value);
  DriveStatus = BSP_ACCELERO_Get_Axes(LSM6DSL_ACCEL_handle, &AccelSensorAxisData);
  DriveStatus = BSP_GYRO_Get_Axes(LSM6DSL_GYRO_handle, &GyroSensorAxisData);
  DriveStatus = BSP_MAGNETO_Get_Axes(LSM303AGR_MAG_handle, &MagnetoSensorAxisData);

  sensor_data->humidity    = (uint16_t) (HUMIDITY_Value * 2);   // in 0.5%
  sensor_data->temperature = (uint16_t) (TEMPERATURE_Value * 10);  // in 10th's of degC
  sensor_data->pressure    = (uint16_t) (PRESSURE_Value * 10);        // in 10th's of hPa
  sensor_data->accel_x   = AccelSensorAxisData.AXIS_X;
  sensor_data->accel_y   = AccelSensorAxisData.AXIS_Y;
  sensor_data->accel_z   = AccelSensorAxisData.AXIS_Z;
  sensor_data->gyro_x    = GyroSensorAxisData.AXIS_X;
  sensor_data->gyro_y    = GyroSensorAxisData.AXIS_Y;
  sensor_data->gyro_z    = GyroSensorAxisData.AXIS_Z;
  sensor_data->magneto_x = MagnetoSensorAxisData.AXIS_X;
  sensor_data->magneto_y = MagnetoSensorAxisData.AXIS_Y;
  sensor_data->magneto_z = MagnetoSensorAxisData.AXIS_Z;  
}


void BSP_humidity_Read( sensor_t *sensor_data)
{
  float HUMIDITY_Value = 0;

  BSP_HUMIDITY_Get_Hum(HUMIDITY_handle, &HUMIDITY_Value);
  sensor_data->humidity    = HUMIDITY_Value;
}


void BSP_accel_Read( sensor_t *sensor_data)
{
  SensorAxes_t AccelAxisData;

  DriveStatus = BSP_ACCELERO_Get_Axes(LSM6DSL_ACCEL_handle, &AccelAxisData);
  //DriveStatus = BSP_ACCELERO_Get_Axes(LSM303AGR_ACCEL_handle, &AccelAxisData);

  sensor_data->accel_x   = AccelAxisData.AXIS_X;
  sensor_data->accel_y   = AccelAxisData.AXIS_Y;
  sensor_data->accel_z   = AccelAxisData.AXIS_Z;
}

void BSP_temperature_Read( sensor_t *sensor_data)
{
  float TEMPERATURE_Value = 0;

  BSP_TEMPERATURE_Get_Temp(TEMPERATURE_handle, &TEMPERATURE_Value);
  sensor_data->temperature = TEMPERATURE_Value;
}

void BSP_pressure_Read( sensor_t *sensor_data)
{
  float PRESSURE_Value = 0;

  BSP_PRESSURE_Sensor_Enable( PRESSURE_handle );
  BSP_PRESSURE_Get_Press(PRESSURE_handle, &PRESSURE_Value);
  sensor_data->pressure = PRESSURE_Value;
}

void BSP_gyro_Read( sensor_t *sensor_data)
{
  SensorAxes_t GyroAxisData;
  
  DriveStatus = BSP_GYRO_Get_Axes(LSM6DSL_GYRO_handle, &GyroAxisData);
  sensor_data->gyro_x = GyroAxisData.AXIS_X;
  sensor_data->gyro_y = GyroAxisData.AXIS_Y;
  sensor_data->gyro_z = GyroAxisData.AXIS_Z;
}

void BSP_magneto_Read( sensor_t *sensor_data)
{
  SensorAxes_t MagAxisData;

  DriveStatus = BSP_MAGNETO_Get_Axes(LSM303AGR_MAG_handle, &MagAxisData);
  sensor_data->magneto_x = MagAxisData.AXIS_X;  
  sensor_data->magneto_y = MagAxisData.AXIS_Y;  
  sensor_data->magneto_z = MagAxisData.AXIS_Z;  
}


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
