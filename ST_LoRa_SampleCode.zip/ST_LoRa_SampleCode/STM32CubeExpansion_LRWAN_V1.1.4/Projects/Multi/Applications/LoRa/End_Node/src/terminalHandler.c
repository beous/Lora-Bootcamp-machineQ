/******************************************************************************
  * @file    terminalHandler.h
  * @author  Alec Bath
  * @version V1.0
  * @date    29-April-2018
  * @brief   Terminal handler utilities
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2017 STMicroelectronics International N.V. 
  * All rights reserved.</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without 
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice, 
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other 
  *    contributors to this software may be used to endorse or promote products 
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this 
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under 
  *    this license is void and will automatically terminate your rights under 
  *    this license. 
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" 
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT 
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT 
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */



/* Includes ------------------------------------------------------------------*/
#include "hw.h"
#include "terminalHandler.h"

/* Private typedef -----------------------------------------------------------*/
typedef enum
{
    state_DevEUI,
    state_AppEUI,
    state_AppKEY,
    state_TxDutyCycle,
    state_ADRState,
    state_defaultDR,
    state_AppPort,
    state_ConfirmMsg,
    state_Class,
    state_numjointrials
} e_ConfigState;


typedef enum
{
  EE_DEVEUI = 0x00,
  EE_APPEUI = 0x08,
  EE_APPKEY = 0x10,
  EE_TX_DUTY_CYCLE = 0x20,
  EE_COMM_FLAG = 0x24,
  
} eCOMM_EEPROM;



/* Private define ------------------------------------------------------------*/
#define COMM_EEPROM_BASE_ADDR  0x08080200

/* Private macro -------------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
static HAL_StatusTypeDef write_commission_to_eeprom (RxBufData_t* BufInfo);  // store 32 bytes (8 words) (deveui=8/appeui=8/appkey=16)
static HAL_StatusTypeDef hex_ascii_to_byte(uint8_t* n);
static HAL_StatusTypeDef decimal_ascii_to_word (uint8_t* in_ascii, uint32_t* outword, uint32_t stringsize);

/* Private variables ---------------------------------------------------------*/
extern RxBufData_t RxBufferData;
UART_HandleTypeDef huart2;

/* Private functions ---------------------------------------------------------*/

HAL_StatusTypeDef CheckCommission(RxBufData_t* RxBuf)  // check eeprom for commisssioning confirmation
{
  HAL_StatusTypeDef HAL_Stat = HAL_ERROR;
  uint32_t eepromval;

  eepromval = * (uint32_t*)(COMM_EEPROM_BASE_ADDR + EE_COMM_FLAG);
  
  if (eepromval != 0) HAL_Stat = HAL_OK;
    
  return HAL_Stat; 
  
}

HAL_StatusTypeDef CheckForReCommission(RxBufData_t* RxBuf)
{
  HAL_StatusTypeDef HAL_Stat = HAL_ERROR;
  uint32_t i, timeoutval = 10;
  
  HAL_UART_Receive_IT(&huart2, &RxBuf->RxByte, 1);
  while ( (RxBuf->RxByte != 'c') && (RxBuf->RxByte != 'C') && (timeoutval != 0) ) // wait for 'c'
  {
        for (i=2000000; i!=0; i--);
        BSP_LED_Toggle(LED1);
        printf(".");
        timeoutval--;
  }

  if (timeoutval == 0) HAL_Stat = HAL_TIMEOUT;
  else if ( (RxBuf->RxByte == 'c') || (RxBuf->RxByte == 'C') )
  {
    RxBuf->commissioning_flag = 0;
    HAL_Stat = HAL_OK;
  }
  
  return HAL_Stat; 
}


HAL_StatusTypeDef GetCommission(RxBufData_t* RxBuf)  // get commisssioning data from eeprom, if valid
{
  HAL_StatusTypeDef HAL_Stat = HAL_ERROR;
  uint32_t i;
  //uint8_t *BufPtr;

  if (CheckCommission(RxBuf) == HAL_OK)
  {
    for (i=0; i!=8; i++) RxBuf->deveui_val[i] = *(uint32_t*)(COMM_EEPROM_BASE_ADDR + EE_DEVEUI + i);
    for (i=0; i!=8; i++) RxBuf->appeui_val[i] = *(uint32_t*)(COMM_EEPROM_BASE_ADDR + EE_APPEUI + i);
    for (i=0; i!=16; i++) RxBuf->appkey_val[i] = *(uint32_t*)(COMM_EEPROM_BASE_ADDR + EE_APPKEY + i);
    RxBuf->tx_dutycycle = *(uint32_t*)(COMM_EEPROM_BASE_ADDR + EE_TX_DUTY_CYCLE);
    RxBuf->commissioning_flag = *(uint32_t*)(COMM_EEPROM_BASE_ADDR + EE_COMM_FLAG);
    HAL_Stat = HAL_OK;
  }
  
  return HAL_Stat; 
}


HAL_StatusTypeDef SetCommission(RxBufData_t* RxBuf)
{
  HAL_StatusTypeDef HAL_Status;
  volatile uint32_t i = 0;
  
    while(RxBuf->commissioning_flag == 0)
    {
        if (RxBuf->deveui_flag == 0)  // process DEVEUI character entry
        {
            printf("\r\n\n\nEnter your 8-byte DEVEUI as 16 characters and press ENTER");
            printf("\r\n  (e.g. a0b0c0d0e0f01122)");
            printf("\r\n\n> ");
            HAL_UART_Receive_IT(&huart2, &RxBuf->RxByte, 1);
            while (RxBuf->CR_flag == 0)  // wait for end of com port command
            {
                BSP_LED_Toggle(LED1);
                for (i=1000000; i!=0; i--);      
            }
            
            RxBuf->ConfigState = state_DevEUI;
            HAL_Status = process_config_states (RxBuf);
            if (HAL_Status == HAL_OK)
            {
                RxBuf->deveui_flag = 1;  // set success flag
                printf("\r\n\nSUCCESS!");
            }
        }
        
        if ( (RxBuf->deveui_flag == 1) && (RxBuf->appeui_flag == 0) )  // process APPEUI character entry after DEVEUI flag set
        {
            printf("\r\n\n\nEnter your 8-byte APPEUI as 16 characters and press ENTER");
            printf("\r\n  (e.g. 1122334455667788)");
            printf("\r\n\n> ");

            HAL_UART_Receive_IT(&huart2, &RxBuf->RxByte, 1);
            while (RxBuf->CR_flag == 0)  // wait for end of com port command
            {
                BSP_LED_Toggle(LED1);
                for (i=1000000; i!=0; i--);      
            }

            RxBuf->ConfigState = state_AppEUI;  // next state
            HAL_Status = process_config_states (RxBuf);
            if (HAL_Status == HAL_OK)
            {
                RxBuf->appeui_flag = 1;  // set success flag
                printf("\r\n\nSUCCESS!");
            }
        }

        if ( (RxBuf->deveui_flag == 1) && (RxBuf->appeui_flag == 1) && (RxBuf->appkey_flag == 0) )  // process APPKEY character entry after others are set
        {
            printf("\r\n\n\nEnter your 16-byte APPKEY as 32 characters and press ENTER");
            printf("\r\n  (e.g. 1122334455667788AABBCCDDEEFF0123)");
            printf("\r\n\n> ");

            HAL_UART_Receive_IT(&huart2, &RxBuf->RxByte, 1);
            while (RxBuf->CR_flag == 0)  // wait for end of com port command
            {
                BSP_LED_Toggle(LED1);
                for (i=1000000; i!=0; i--);      
            }

            RxBuf->ConfigState = state_AppKEY;  // next state
            HAL_Status = process_config_states (RxBuf);
            if (HAL_Status == HAL_OK)
            {
              RxBuf->appkey_flag = 1;  // set success flag
              printf("\r\n\nSUCCESS!");
            }
        }
        if ( (RxBuf->deveui_flag == 1) && (RxBuf->appeui_flag == 1) && (RxBuf->appkey_flag == 1) && (RxBuf->dutycycle_flag == 0) )   // all data correct?
        {
            printf("\r\n\n\nEnter your Transmit Duty Cycle in mS and press ENTER");
            printf("\r\n  (e.g. 10000 is 10 seconds)");
            printf("\r\n\n> ");

            HAL_UART_Receive_IT(&huart2, &RxBuf->RxByte, 1);
            while (RxBuf->CR_flag == 0)  // wait for end of com port command
            {
                BSP_LED_Toggle(LED1);
                for (i=1000000; i!=0; i--);      
            }

            RxBuf->ConfigState = state_TxDutyCycle;  // next state
            HAL_Status = process_config_states (RxBuf);
            if (HAL_Status == HAL_OK)
            {
              RxBuf->dutycycle_flag = 1;  // set success flag
              RxBuf->commissioning_flag = 1;  // set success flag
              RxBuf->eeprom_base_addr = COMM_EEPROM_BASE_ADDR;
              HAL_Status = write_commission_to_eeprom (RxBuf);  // store 32 bytes (8 words) (deveui=8/appeui=8/appkey=16)
              if (HAL_Status == HAL_OK)
              {
                  RxBuf->write_eeprom_flag = 1;  // eeprom has been written
                  printf("\r\n\n\n\nSUCCESS!  You are commissioned!!");
              }

            }
        }
    }

    return HAL_Status;
}


HAL_StatusTypeDef process_config_states (RxBufData_t* BufInfo)
{
  HAL_StatusTypeDef HAL_Status;
  uint32_t val_cnt;
  
  HAL_Status = HAL_ERROR;
  
  switch (BufInfo->ConfigState)
  {
    case state_DevEUI:

      if (BufInfo->RxBufCount == 17)  // 16 ascii bytes + CR
      {
        for (val_cnt=0; val_cnt!=8; val_cnt++)  // cycle thru 8 ascii pairs
        {
            HAL_Status = (hex_ascii_to_byte(&BufInfo->RxBuffer[val_cnt*2]));  // get MSB/LSB pair
            if (HAL_Status != HAL_OK) break;
            BufInfo->deveui_val[val_cnt] = BufInfo->RxBuffer[val_cnt*2];  // update deveui value
        }
      }
      break;

    case state_AppEUI:
      if (BufInfo->RxBufCount == 17)  // 16 ascii bytes + CR
      {
        for (val_cnt=0; val_cnt!=8; val_cnt++)  // cycle thru 8 ascii pairs
        {
            HAL_Status = (hex_ascii_to_byte(&BufInfo->RxBuffer[val_cnt*2]));  
            if (HAL_Status != HAL_OK) break;
            BufInfo->appeui_val[val_cnt] = BufInfo->RxBuffer[val_cnt*2];  
        }
      }
      break;

    case state_AppKEY:
      if (BufInfo->RxBufCount == 33)  // 32 ascii bytes + CR
      {
        for (val_cnt=0; val_cnt!=16; val_cnt++)  // cycle thru 16 ascii pairs
        {
            HAL_Status = (hex_ascii_to_byte(&BufInfo->RxBuffer[val_cnt*2])); 
            if (HAL_Status != HAL_OK) break;
            BufInfo->appkey_val[val_cnt] = BufInfo->RxBuffer[val_cnt*2]; 
        }
      }
      break;

    case state_TxDutyCycle:
      HAL_Status = decimal_ascii_to_word(BufInfo->RxBuffer, &BufInfo->tx_dutycycle, BufInfo->RxBufCount-1);  // get MSB and shift to high nibble, inc ascii counter
      if (HAL_Status != HAL_OK) break;
    break;

    	default:
    		break;
    }    
    BufInfo->RxBufCount = 0;  // reset msg byte counter
    BufInfo->CR_flag = 0;  // reset CR flag
    return HAL_Status;
}


HAL_StatusTypeDef decimal_ascii_to_word (uint8_t* in_ascii, uint32_t* outword, uint32_t stringsize)
{
  HAL_StatusTypeDef HAL_Stat = HAL_ERROR;
  //uint8_t n, buf[6];
  volatile uint32_t n, bufval, powval;

//  *outword = 5 * pow(2,2);
  *outword = 0;
  
  if (stringsize >=7) return HAL_Stat;  // only process 0-999999  
  for (n=0; n!=stringsize; n++)
  {
    if ((in_ascii[n] >= '0') && (in_ascii[n] <= '9'))  bufval = (in_ascii[n] - '0');  // get the value
      else  return HAL_Stat;  // error in ascii value  
    powval = pow(10, ((stringsize - 1)-n));
    bufval = bufval * powval;
    //buf[n] = buf[n] * pow(10, ((stringsize - 1)-n));  // 5 * 10^2 = 500
    *outword += bufval;
  }

  HAL_Stat = HAL_OK;
  
  return HAL_Stat;
}


HAL_StatusTypeDef hex_ascii_to_byte(uint8_t* n)
{
    HAL_StatusTypeDef HAL_Stat = HAL_ERROR;
    uint8_t msb, lsb;
  
    msb = *n;
    lsb = *(n+1);
  
    if ((msb >= '0') && (msb <= '9'))  msb = (msb - '0') << 4;  // get the value
    else if ((msb >= 'a') && (msb <= 'f'))  msb = (((msb - 'a')+10) << 4);  // get the value a-f    
    else if ((msb >= 'A') && (msb <= 'F'))  msb = (((msb - 'A')+10) << 4);  // get the value A-F
    else  return HAL_Stat;  // error in ascii value  
    
    if ((lsb >= '0') && (lsb <= '9'))  lsb = lsb - '0';  // get the value
    else if ((lsb >= 'a') && (lsb <= 'f'))  lsb = (lsb - 'a')+10;  // get the value a-f    
    else if ((lsb >= 'A') && (lsb <= 'F'))  lsb = (lsb - 'A')+10;  // get the value A-F
    else  return HAL_Stat;  // error in ascii value  
    
    *n = msb + lsb;
    HAL_Stat = HAL_OK;
    return HAL_Stat;
}


HAL_StatusTypeDef byte_to_hex_ascii(uint8_t in_byte, uint8_t* pAsciiVals)  // input byte and return ptr to two ascii values
{
    HAL_StatusTypeDef HAL_Stat = HAL_ERROR;
//    uint8_t msb, lsb;
  
    *pAsciiVals = in_byte;  // MSB nibble
    pAsciiVals++;  // LSB nibble
  
    return HAL_Stat;
}


HAL_StatusTypeDef write_commission_to_eeprom (RxBufData_t* BufInfo)  // store 32 bytes (8 words) (deveui=8/appeui=8/appkey=16)
{
  HAL_StatusTypeDef HAL_Status;
  uint32_t i;
  
  HAL_Status = HAL_ERROR;
  
  if (BufInfo->commissioning_flag == 1)
  {
      HAL_Status = HAL_FLASHEx_DATAEEPROM_Unlock(); // enable the data EEPROM access

      for (i=0; i!=10; i++)
      {
        HAL_Status = HAL_FLASHEx_DATAEEPROM_Erase(BufInfo->eeprom_base_addr+(i<<2));  // 0x08080200 - 0x0808023F  (32B)
      }
    
      i =  BufInfo->deveui_val[3] << 24;  // set to MSB
      i += BufInfo->deveui_val[2] << 16;
      i += BufInfo->deveui_val[1] << 8;  
      i += BufInfo->deveui_val[0];        // set to LSB
      HAL_Status = HAL_FLASHEx_DATAEEPROM_Program(FLASH_TYPEPROGRAMDATA_WORD, BufInfo->eeprom_base_addr + EE_DEVEUI, i);

      i =  BufInfo->deveui_val[7] << 24;  // set to MSB
      i += BufInfo->deveui_val[6] << 16;
      i += BufInfo->deveui_val[5] << 8;  
      i += BufInfo->deveui_val[4];        // set to LSB
      HAL_Status = HAL_FLASHEx_DATAEEPROM_Program(FLASH_TYPEPROGRAMDATA_WORD, BufInfo->eeprom_base_addr+(EE_DEVEUI+4), i);

      i =  BufInfo->appeui_val[3] << 24;  // set to MSB
      i += BufInfo->appeui_val[2] << 16;
      i += BufInfo->appeui_val[1] << 8;  
      i += BufInfo->appeui_val[0];        // set to LSB
      HAL_Status = HAL_FLASHEx_DATAEEPROM_Program(FLASH_TYPEPROGRAMDATA_WORD, BufInfo->eeprom_base_addr+EE_APPEUI, i);
      i =  BufInfo->appeui_val[7] << 24;  // set to MSB
      i += BufInfo->appeui_val[6] << 16;
      i += BufInfo->appeui_val[5] << 8;  
      i += BufInfo->appeui_val[4];        // set to LSB
      HAL_Status = HAL_FLASHEx_DATAEEPROM_Program(FLASH_TYPEPROGRAMDATA_WORD, BufInfo->eeprom_base_addr+(EE_APPEUI+4), i);

      i =  BufInfo->appkey_val[3] << 24;  // set to MSB
      i += BufInfo->appkey_val[2] << 16;
      i += BufInfo->appkey_val[1] << 8;  
      i += BufInfo->appkey_val[0];        // set to LSB
      HAL_Status = HAL_FLASHEx_DATAEEPROM_Program(FLASH_TYPEPROGRAMDATA_WORD, BufInfo->eeprom_base_addr+EE_APPKEY, i);
      i =  BufInfo->appkey_val[7] << 24;  // set to MSB
      i += BufInfo->appkey_val[6] << 16;
      i += BufInfo->appkey_val[5] << 8;  
      i += BufInfo->appkey_val[4];        // set to LSB
      HAL_Status = HAL_FLASHEx_DATAEEPROM_Program(FLASH_TYPEPROGRAMDATA_WORD, BufInfo->eeprom_base_addr+(EE_APPKEY+4), i);
      i =  BufInfo->appkey_val[11] << 24;  // set to MSB
      i += BufInfo->appkey_val[10] << 16;
      i += BufInfo->appkey_val[9] << 8;  
      i += BufInfo->appkey_val[8];        // set to LSB
      HAL_Status = HAL_FLASHEx_DATAEEPROM_Program(FLASH_TYPEPROGRAMDATA_WORD, BufInfo->eeprom_base_addr+(EE_APPKEY+8), i);
      i =  BufInfo->appkey_val[15] << 24;  // set to MSB
      i += BufInfo->appkey_val[14] << 16;
      i += BufInfo->appkey_val[13] << 8;  
      i += BufInfo->appkey_val[12];        // set to LSB
      HAL_Status = HAL_FLASHEx_DATAEEPROM_Program(FLASH_TYPEPROGRAMDATA_WORD, BufInfo->eeprom_base_addr+(EE_APPKEY+12), i);

      i =  BufInfo->tx_dutycycle;
      HAL_Status = HAL_FLASHEx_DATAEEPROM_Program(FLASH_TYPEPROGRAMDATA_WORD, BufInfo->eeprom_base_addr+EE_TX_DUTY_CYCLE, i);
      
      i = BufInfo->commissioning_flag;
      HAL_Status = HAL_FLASHEx_DATAEEPROM_Program(FLASH_TYPEPROGRAMDATA_WORD, BufInfo->eeprom_base_addr+EE_COMM_FLAG, i);

      HAL_Status = HAL_FLASHEx_DATAEEPROM_Lock();  // disable the data EEPROM access

      HAL_Status = HAL_OK;
  }

  return HAL_Status;
}


void Terminal_UART_Init(void)
{
  GPIO_InitTypeDef  GPIO_InitStruct={0};

  __USART2_CLK_ENABLE();
  __GPIOA_CLK_ENABLE();
  
  //__USART2_FORCE_RESET();
  //__USART2_RELEASE_RESET();

  GPIO_InitStruct.Pin       = GPIO_PIN_2 | GPIO_PIN_3;
  GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull      = GPIO_PULLUP;
  GPIO_InitStruct.Speed     = GPIO_SPEED_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF4_USART2;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONEBIT_SAMPLING_DISABLED;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  HAL_UART_Init(&huart2);

  HAL_NVIC_SetPriority(USART2_IRQn, 3, 1);
  HAL_NVIC_EnableIRQ(USART2_IRQn);
}


void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
  RxBufferData.uartRxError++;  // log the error and restart
  HAL_UART_Receive_IT(&huart2, &RxBufferData.RxByte, 1);
}


void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    RxBufferData.RxBuffer[RxBufferData.RxBufPtr++] = RxBufferData.RxByte;
    RxBufferData.RxBufCount++;
    if (RxBufferData.RxByte == 0x0D)  // 0x0D or 0x0D+0x0A
    {
        RxBufferData.CR_flag = 1;  // ready to decode
        RxBufferData.RxBufPtr = 0; // reset buf pointer
    }
   
    else
    {
        HAL_UART_Receive_IT(&huart2, &RxBufferData.RxByte, 1);
    }
}


int fputc(int ch, FILE *f)  // Retarget printf() to USART2
{
  HAL_UART_Transmit(&huart2, (uint8_t*) &ch, 1, 2000);

  return ch;
}

int fgetc(FILE *f)  // Retarget scanf() to USART2
{
  uint8_t TempByte;

  HAL_UART_Receive(&huart2, (uint8_t*) &TempByte, 1, 2000);

  return TempByte;
}


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
