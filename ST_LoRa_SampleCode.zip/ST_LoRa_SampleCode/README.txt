Thanks for choosing MACHINEQ, lengthier instructions for this dev kit are available at https://machineq.com/st-lora-dev-kit/

To open this project in Keil (or your choice of IDE) use the path below:
\Comcast_LoRaWAN_V1.1.4\STM32CubeExpansion_LRWAN_V1.1.4\Projects\Multi\Applications\LoRa\End_Node\MDK-ARM\B-L072Z-LRWAN1\Lora

Once the project is open, please compile the project in your IDE, then look for the commissioning.h file and insert your LoRa credentials on lines 92-93

This project's main file is main_comcast_rev2.c found under the Projects/End_Node folder

Terminal Config = 115200, 8b, 1 stopbit, no parity, no flow control