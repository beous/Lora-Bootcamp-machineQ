 /******************************************************************************
  ******************************************************************************
  * @file    sensor_drivers.c
  * @author  Alec Bath
  * @version V1.0.0
  * @date    13-April-2018
  * @brief   Sensor drivers for IKS-01A2 sensor shield used on the B-L072Z-LRWAN LoRa Discovery Board
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2017 STMicroelectronics International N.V. 
  * All rights reserved.</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without 
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice, 
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other 
  *    contributors to this software may be used to endorse or promote products 
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this 
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under 
  *    this license is void and will automatically terminate your rights under 
  *    this license. 
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" 
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT 
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT 
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
  
  /* Includes ------------------------------------------------------------------*/
#include "sensor_drivers.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
  I2C_HandleTypeDef I2C_InitStruct;
  
/* Private function prototypes -----------------------------------------------*/
static void Sensor_I2C_Error(void);
HAL_StatusTypeDef Sensor_I2C_Read(uint8_t DevAddr, uint8_t RegAddr, uint8_t *pBuffer, uint16_t nBytesToRead);
HAL_StatusTypeDef Sensor_I2C_Write(uint8_t DevAddr, uint8_t RegAddr, uint8_t *pBuffer, uint16_t nBytesToWrite);
static void dumbsensordelay(uint32_t delayval);


/* Exported functions ---------------------------------------------------------*/

void Sensor_I2C_Init(void)
{
  GPIO_InitTypeDef  GPIO_InitStruct;

  
  I2C_InitStruct.Init.Timing = 0x00B1112E; /* Analog Filter ON, Rise Time 250ns, Fall Time 100ns */
  I2C_InitStruct.Init.OwnAddress1    = 0x33;
  I2C_InitStruct.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  I2C_InitStruct.Instance            = I2C1;
  
  __GPIOB_CLK_ENABLE();

  GPIO_InitStruct.Pin        = GPIO_PIN_8 | GPIO_PIN_9;
  GPIO_InitStruct.Mode       = GPIO_MODE_AF_OD;
  GPIO_InitStruct.Speed      = GPIO_SPEED_FAST;
  GPIO_InitStruct.Pull       = GPIO_NOPULL;
  GPIO_InitStruct.Alternate  = GPIO_AF4_I2C1;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct );

  __I2C1_CLK_ENABLE();
  __I2C1_FORCE_RESET();
  __I2C1_RELEASE_RESET();
  
  HAL_NVIC_SetPriority(I2C1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(I2C1_IRQn);

  HAL_I2C_Init(&I2C_InitStruct);
}


HAL_StatusTypeDef Sensor_I2C_Read(uint8_t DevAddr, uint8_t RegAddr, uint8_t *pBuffer, uint16_t nBytesToRead )
{
  HAL_StatusTypeDef status = HAL_OK;

//  if ( nBytesToRead > 1 ) RegAddr |= 0x80;  // autoincrement function

  status = HAL_I2C_Mem_Read(&I2C_InitStruct, DevAddr, (uint16_t)RegAddr, I2C_MEMADD_SIZE_8BIT, pBuffer, nBytesToRead, 1000);

  if( status != HAL_OK )
  {
    Sensor_I2C_Error();
    return 1;
  }
  else
  {
    return 0;
  }
}


HAL_StatusTypeDef Sensor_I2C_Write(uint8_t DevAddr, uint8_t RegAddr, uint8_t *pBuffer, uint16_t nBytesToWrite )
{
  HAL_StatusTypeDef status = HAL_OK;

  //if ( nBytesToWrite > 1 ) RegAddr |= 0x80;  // autoincrement function

  status = HAL_I2C_Mem_Write(&I2C_InitStruct, DevAddr, (uint16_t)RegAddr, I2C_MEMADD_SIZE_8BIT, pBuffer, nBytesToWrite, 1000);

  if( status != HAL_OK )
  {
    Sensor_I2C_Error();
    return status;
  }
  else
  {
    return status;
  }
}


static void Sensor_I2C_Error(void)
{
  HAL_I2C_DeInit(&I2C_InitStruct);
  Sensor_I2C_Init();
}

/*
  DriveStatus = BSP_MAGNETO_Init(LSM303AGR_M_0, &LSM303AGR_MAG_handle);
  DriveStatus = BSP_MAGNETO_Sensor_Enable(LSM303AGR_MAG_handle);
*/


static void dumbsensordelay(uint32_t delayval)
{
  volatile uint32_t delay;
  for (delay=(delayval*1000); delay!=0; delay--);
}

  
HAL_StatusTypeDef MyMagInit(mysensor_t *mysensor_data)
{
  uint8_t tmp;

  tmp = 0x0C;
  if (Sensor_I2C_Write(LSM303AGR_MAG_ADDR, LSM303AGR_MAG_CFG_REG_A, &tmp, 1) != HAL_OK)  // set ODR high, cont mode
    return HTS221_ERROR;

  tmp = 0x10;
  if (Sensor_I2C_Write(LSM303AGR_MAG_ADDR, LSM303AGR_MAG_CFG_REG_C, &tmp, 1) != HAL_OK)  // BDU enabled
    return HTS221_ERROR;

  return HTS221_OK;
}

HAL_StatusTypeDef MyMagDisable(void)
{
  uint8_t tmp;

  tmp = 0x02;   // LSM303AGR_MAG_MD_IDLE1_MODE
  if (Sensor_I2C_Write(LSM303AGR_MAG_ADDR, LSM303AGR_MAG_CFG_REG_A, &tmp, 1) != HAL_OK)  // Idle mode
    return HTS221_ERROR;

  return HTS221_OK;
}


HAL_StatusTypeDef MyMagRead(mysensor_t *mysensor_data)
{
  uint8_t buffer[6];

  if (Sensor_I2C_Read(LSM303AGR_MAG_ADDR, LSM303AGR_MAG_OUTX_L_REG, buffer, 6) != HAL_OK)
    return HTS221_ERROR;

  mysensor_data->magneto_x = (buffer[1]<<8) + buffer[0];
  mysensor_data->magneto_y = (buffer[3]<<8) + buffer[2];
  mysensor_data->magneto_z = (buffer[5]<<8) + buffer[4];

  return HTS221_OK;
}


HAL_StatusTypeDef MyAccelGyroInit(mysensor_t *mysensor_data)
{
  uint8_t tmp;

//  tmp = 0x44;
//  if (Sensor_I2C_Write(LSM6DSL_ADDR, LSM6DSL_ACC_GYRO_CTRL3_C, &tmp, 1) != HAL_OK)  // set auto increment (default), BDU
//    return HTS221_ERROR;

  tmp = 0x40;
  if (Sensor_I2C_Write(LSM6DSL_ADDR, LSM6DSL_ACC_GYRO_CTRL1_XL, &tmp, 1) != HAL_OK)  // 104Hz, 2g mode
    return HTS221_ERROR;

  tmp = 0x48;
  if (Sensor_I2C_Write(LSM6DSL_ADDR, LSM6DSL_ACC_GYRO_CTRL2_G, &tmp, 1) != HAL_OK)  // 104Hz, 1000dps FS mode
    return HTS221_ERROR;

  
  return HTS221_OK;
}




HAL_StatusTypeDef MyAccelGyroDisable(void)
{
  uint8_t tmp = 0;

  if (Sensor_I2C_Write(LSM6DSL_ADDR, LSM6DSL_ACC_GYRO_CTRL1_XL, &tmp, 1) != HAL_OK)  // 
     return HTS221_ERROR;

  if (Sensor_I2C_Write(LSM6DSL_ADDR, LSM6DSL_ACC_GYRO_CTRL2_G, &tmp, 1) != HAL_OK)  // 
    return HTS221_ERROR;

  return HTS221_OK;
}


HAL_StatusTypeDef MyAccelGyroRead(mysensor_t *mysensor_data)
{
  uint8_t buffer[12];

  if (Sensor_I2C_Read(LSM6DSL_ADDR, LSM6DSL_ACC_GYRO_OUTX_L_G, buffer, 12) != HAL_OK)
    return HTS221_ERROR;

  mysensor_data->gyro_x = (buffer[1]<<8) + buffer[0];
  mysensor_data->gyro_y = (buffer[3]<<8) + buffer[2];
  mysensor_data->gyro_z = (buffer[5]<<8) + buffer[4];
  mysensor_data->accel_x = (buffer[7]<<8) + buffer[6];
  mysensor_data->accel_y = (buffer[9]<<8) + buffer[8];
  mysensor_data->accel_z = (buffer[11]<<8) + buffer[10];

  return HTS221_OK;
}




HAL_StatusTypeDef MyPressureInit(mysensor_t *mysensor_data)
{
  uint8_t tmp = 0x01;

  if (Sensor_I2C_Write(LPS22HB_ADDR, LPS22HB_RES_CONF_REG, &tmp, 1) != HAL_OK)  // low power mode not low noise
    return HTS221_ERROR;


  //tmp = LPS22HB_ODR_ONE_SHOT;  // ODR = ONE_SHOT
  tmp = 0x12;    // ODR=1Hz, no LPF, BDU
  if (Sensor_I2C_Write(LPS22HB_ADDR, LPS22HB_CTRL_REG1, &tmp, 1) != HAL_OK)
    return HTS221_ERROR;

//  if( LPS22HB_Set_AutomaticIncrementRegAddress( (void *)handle, LPS22HB_DISABLE) == LPS22HB_ERROR )
  //tmp = 0x00;
  //if (Sensor_I2C_Write(LPS22HB_ADDR, LPS22HB_CTRL_REG2, &tmp, 1) != HAL_OK)  // 
  //  return HTS221_ERROR;

  return HTS221_OK;
}


HAL_StatusTypeDef MyPressureDisable(void)
{
  uint8_t tmp = 0x00;

  if (Sensor_I2C_Write(LPS22HB_ADDR, LPS22HB_CTRL_REG1, &tmp, 1) != HAL_OK)  // powerdown mode
    return HTS221_ERROR;

  return HTS221_OK;
}


HAL_StatusTypeDef MyPressureRead(mysensor_t *mysensor_data)
{
  uint8_t buffer[3];
  uint32_t tmp = 0;
//  uint32_t i;
  int32_t *raw_press;
  

  buffer[0] = 0x01;  // start a one-shot read
  if (Sensor_I2C_Write(LPS22HB_ADDR, LPS22HB_CTRL_REG2, buffer, 1) != HAL_OK)  // 
    return HTS221_ERROR;
  
  dumbsensordelay(1000);

  buffer[0] = 0;
  while ((buffer[0] & LPS22HB_PDA_BIT) != LPS22HB_PDA_BIT)
  {
      if (Sensor_I2C_Read(LPS22HB_ADDR, LPS22HB_STATUS_REG, buffer, 1) != HAL_OK)  // wait for PDA to set
        return HTS221_ERROR;
      dumbsensordelay(1000);
  }
  
  //if (Sensor_I2C_Read(LPS22HB_ADDR, LPS22HB_PRESS_OUT_XL_REG, buffer, 3) != HAL_OK)
  //  return HTS221_ERROR;

  if (Sensor_I2C_Read(LPS22HB_ADDR, LPS22HB_PRESS_OUT_XL_REG, &buffer[0], 1) != HAL_OK)
    return HTS221_ERROR;

  if (Sensor_I2C_Read(LPS22HB_ADDR, LPS22HB_PRESS_OUT_L_REG, &buffer[1], 1) != HAL_OK)
    return HTS221_ERROR;

  if (Sensor_I2C_Read(LPS22HB_ADDR, LPS22HB_PRESS_OUT_H_REG, &buffer[2], 1) != HAL_OK)
    return HTS221_ERROR;

  tmp = ((uint32_t)buffer[0]) + ((uint32_t)(buffer[1] << 8)) + ((uint32_t)(buffer[2] << 16));

  if(tmp & 0x00800000)    /* convert the 2's complement 24 bit to 2's complement 32 bit */
    tmp |= 0xFF000000;

  *raw_press = ((int32_t)tmp);
//  mysensor_data->pressure = (float)(*raw_press / 4096);
  mysensor_data->pressure = (float)(tmp / 4096);

  return HTS221_OK;
}

    
HAL_StatusTypeDef MyHumidityInit(mysensor_t *mysensor_data)
{
  uint8_t tmp = 0x00;

  if (Sensor_I2C_Write(HTS221_ADDR, HTS221_CTRL_REG1, &tmp, 1) != HAL_OK)  // powerdown
    return HTS221_ERROR;

  tmp = 0x85;    // Powerup, Enable BDU, ODR = 1Hz
  if (Sensor_I2C_Write(HTS221_ADDR, HTS221_CTRL_REG1, &tmp, 1) != HAL_OK) 
    return HTS221_ERROR;

  return HTS221_OK;
}


HAL_StatusTypeDef MyHumidityDisable(void)
{
  uint8_t tmp = 0x00;

  if (Sensor_I2C_Write(HTS221_ADDR, HTS221_CTRL_REG1, &tmp, 1) != HAL_OK)  // powerdown
    return HTS221_ERROR;

  return HTS221_OK;
}


HAL_StatusTypeDef MyHumidityRead(mysensor_t *mysensor_data)
{
  int16_t H0_T0_out, H1_T0_out, H_T_out;
  int16_t H0_rh, H1_rh;
  uint8_t buffer[2];
  float   tmp_f;
//  float HUMIDITY_Value = 0;
  uint16_t* value;

  if (Sensor_I2C_Read(HTS221_ADDR, (HTS221_H0_RH_X2 | 0x80), buffer, 2) != HAL_OK)   // autoincrement function
    return HTS221_ERROR;
 
  H0_rh = buffer[0] >> 1;
  H1_rh = buffer[1] >> 1;

  if (Sensor_I2C_Read(HTS221_ADDR, (HTS221_H0_T0_OUT_L | 0x80), buffer, 2) != HAL_OK) // autoincrement function
    return HTS221_ERROR;

  H0_T0_out = (((uint16_t)buffer[1]) << 8) | (uint16_t)buffer[0];

  if (Sensor_I2C_Read(HTS221_ADDR, (HTS221_H1_T0_OUT_L | 0x80), buffer, 2) != HAL_OK) // autoincrement function
    return HTS221_ERROR;

  H1_T0_out = (((uint16_t)buffer[1]) << 8) | (uint16_t)buffer[0];

  if (Sensor_I2C_Read(HTS221_ADDR, (HTS221_HR_OUT_L_REG | 0x80), buffer, 2) != HAL_OK)
    return HTS221_ERROR;

  H_T_out = (((uint16_t)buffer[1]) << 8) | (uint16_t)buffer[0];

  tmp_f = (float)(H_T_out - H0_T0_out) * (float)(H1_rh - H0_rh) / (float)(H1_T0_out - H0_T0_out)  +  H0_rh;

  mysensor_data->humidity  = tmp_f;

  return HTS221_OK;
}  


HAL_StatusTypeDef MyHTS221_TempRead(mysensor_t *mysensor_data)
{
  int16_t T0_out, T1_out, T_out, T0_degC_x8_u16, T1_degC_x8_u16, T0_degC, T1_degC;
  uint8_t buffer[4], tmp;
  float   tmp_f;

  if (Sensor_I2C_Read(HTS221_ADDR, (HTS221_T0_DEGC_X8 | 0x80), buffer, 2) != HAL_OK)
    return HTS221_ERROR;
  if (Sensor_I2C_Read(HTS221_ADDR, HTS221_T0_T1_DEGC_H2, &tmp, 1) != HAL_OK)
    return HTS221_ERROR;

  T0_degC_x8_u16 = (((uint16_t)(tmp & 0x03)) << 8) | ((uint16_t)buffer[0]);
  T1_degC_x8_u16 = (((uint16_t)(tmp & 0x0C)) << 6) | ((uint16_t)buffer[1]);
  T0_degC = T0_degC_x8_u16 >> 3;
  T1_degC = T1_degC_x8_u16 >> 3;

  if (Sensor_I2C_Read(HTS221_ADDR, (HTS221_T0_OUT_L | 0x80), buffer, 4) != HAL_OK)
    return HTS221_ERROR;

  T0_out = (((uint16_t)buffer[1]) << 8) | (uint16_t)buffer[0];
  T1_out = (((uint16_t)buffer[3]) << 8) | (uint16_t)buffer[2];

  if (Sensor_I2C_Read(HTS221_ADDR, (HTS221_TEMP_OUT_L_REG | 0x80), buffer, 2) != HAL_OK)
    return HTS221_ERROR;

  T_out = (((uint16_t)buffer[1]) << 8) | (uint16_t)buffer[0];

  tmp_f = (float)(T_out - T0_out) * (float)(T1_degC - T0_degC) / (float)(T1_out - T0_out)  +  T0_degC;

  mysensor_data->temperature = tmp_f;
  
  return HTS221_OK;
}


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
